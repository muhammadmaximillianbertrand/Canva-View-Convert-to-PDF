// canvaPrint.js
// Automates the printing of Canva "Only View" slides through browser DevTools.

// Save Title
var baseTitle = document.title;
// Count number of pages
var nbPages = document.querySelector('div[role="slider"]').nextElementSibling.children.length;
// Go back to beginning of document
[...Array(nbPages)].map((_, i) => {
  document.querySelector('button[aria-label="Previous page"]').click();
});

// Declare print function
var printPageIndex = 0;
var printFunction = () => {
  if (printPageIndex < nbPages) {
    if (printPageIndex != 0) {
      document.querySelector('button[aria-label="Next page"]').click();
    }
    printPageIndex++;
    setTimeout(() => {
      console.log("Print page " + printPageIndex);
      document.title = baseTitle + " - Page " + printPageIndex;
      window.print();
    }, 100);
  } else {
    document.title = baseTitle;
    window.onafterprint = prev_onafterprint;
    console.log("Done");
  }
};

// Set afterPrint callback
var prev_onafterprint = window.onafterprint;
window.onafterprint = () => {
  setTimeout(printFunction, 10);
};

// And launch first print
setTimeout(printFunction, 1000);
