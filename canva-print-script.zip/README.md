# Canva Print Automation Script

This repository contains a simple JavaScript automation script for printing Canva designs that are shared via "Only View" links. Since Canva disables the "Download" feature for such links, this script works by simulating user behavior to print each slide one by one via the browser's print dialog.

## Features

- Automatically navigates to the first slide
- Iterates through all slides
- Sets document title as `BaseTitle - Page N` for PDF naming
- Calls `window.print()` for each slide
- Fully automates the printing process when pasted into Chrome's DevTools Console

## Usage

1. Open the Canva "Only View" link in Google Chrome.
2. Press `Fn + F12` or `Ctrl + Shift + I` to open DevTools.
3. Go to the **Console** tab.
4. Paste the contents of `canvaPrint.js` into the console and press **Enter**.
5. The print dialog will appear for each slide, and you can save them one by one as PDF.

## License

This project is released under the MIT License.
